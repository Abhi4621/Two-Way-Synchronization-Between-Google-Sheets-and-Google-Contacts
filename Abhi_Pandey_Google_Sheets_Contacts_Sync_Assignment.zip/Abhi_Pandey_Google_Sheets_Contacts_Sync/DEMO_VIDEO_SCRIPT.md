# 🎬 DEMO VIDEO RECORDING SCRIPT & WALKTHROUGH GUIDE

**Candidate:** Abhi Pandey  
**Target Duration:** 2 to 3 minutes  
**Recommended Tool:** [Loom](https://www.loom.com) or OBS / Screen Recorder  

---

## 🖥️ Screen Layout Setup Before Recording
1. **Left Half of Screen:** Google Sheet (`Two-Way Contacts Sync`).
2. **Right Half of Screen:** [Google Contacts](https://contacts.google.com) (or connected mobile phone screen mirrored via scrcpy / QuickTime / Phone Link).
3. Ensure both windows are visible side-by-side.

---

## ⏱️ Step-by-Step Script & Actions

### 0:00 – 0:30 | Introduction & Baseline Setup
* **What you say:**
  > *"Hello everyone! My name is Abhi Pandey. In this video, I will be demonstrating an automated, two-way synchronization system between Google Sheets and Google Contacts built with Google Apps Script and the Google People API.*
  > 
  > *As required, we have a fresh Google account. On the left side of my screen, you can see our Google Sheet containing the initial 10 contacts with their respective phone numbers. On the right side, you can see Google Contacts, where all 10 contacts have been automatically created and synced to the connected mobile device."*
* **On Screen:**
  - Point your mouse cursor to the 10 contacts in the Google Sheet (rows 2 to 11).
  - Point your mouse cursor to Google Contacts showing the matching 10 contacts.

---

### 0:30 – 1:15 | Requirement 1: Google Sheet ➔ Google Contacts Sync
* **What you say:**
  > *"Now, let's demonstrate the first direction: Google Sheet to Google Contacts.*
  > 
  > *I will add an 11th contact directly here in the Google Sheet. Let's enter 'Rajesh Kumar' with phone number '+1 650 555 0111'. Notice that the Contact ID and Sync Status are currently empty.*
  > 
  > *Our installable trigger detects this addition immediately. Within seconds, the script calls the Google People API, assigns a unique system resource ID, and marks the status as 'Synced'.*
  > 
  > *Now, switching over to Google Contacts and refreshing: here is 'Rajesh Kumar' with his phone number, instantly available across all connected devices with zero manual effort."*
* **On Screen:**
  - Type `Rajesh Kumar` and `+1 650 555 0111` into Row 12.
  - Watch Column C automatically fill with `people/c...` and Column E turn to `Synced`.
  - Refresh Google Contacts on the right side and click on `Rajesh Kumar` to reveal the phone number.

---

### 1:15 – 2:00 | Requirement 2: Google Contacts (Mobile) ➔ Google Sheet Sync (11 ➔ 12)
* **What you say:**
  > *"Now let's demonstrate the reverse direction: Google Contacts to Google Sheet.*
  > 
  > *Suppose a user creates a new contact on their mobile phone or directly in Google Contacts. Let's click 'Create contact' here in Google Contacts.*
  > 
  > *I'll enter 'Priyanka Sharma' and phone number '+1 650 555 0112', and hit Save.*
  > 
  > *Our background time-driven synchronization engine polls the People API autonomously. It identifies that Priyanka Sharma does not yet exist in our spreadsheet index. Without any manual button clicks, look at row 13 of the Google Sheet — Priyanka Sharma is automatically appended, complete with her phone number and system ID, incrementing our contact count from 11 to 12."*
* **On Screen:**
  - In Google Contacts (right window), click **Create contact**.
  - Enter `Priyanka Sharma` and `+1 650 555 0112`, click **Save**.
  - Switch attention to Google Sheet. Either wait for the 1-minute trigger to fire, or trigger it via the custom menu `🔄 Sync Manager ➔ ⚡ Sync Contacts ➔ Sheet` to show instant execution on camera.
  - Row 13 appears with `Priyanka Sharma` and status `Synced (from Contacts)`.

---

### 2:00 – 2:30 | Technical Highlights & Conclusion
* **What you say:**
  > *"To ensure enterprise-grade stability, our implementation addresses two critical architectural challenges:*
  > 
  > *1. Infinite Loop Prevention: By indexing Google's immutable resourceName in Column C, the system suppresses recursive echo updates.*
  > *2. Concurrency Control: We use Google Apps Script's LockService to ensure race-free execution during simultaneous sheet edits and background polling.*
  > 
  > *The complete source code, manifest, and step-by-step documentation are submitted in the accompanying repository and document.*
  > 
  > *Thank you for your time and consideration!"*
* **On Screen:**
  - Quickly show the Apps Script editor with `Code.gs` and `appsscript.json`.
  - Smile and end the recording.

---

## 💡 Quick Tips for High Score:
1. Speak clearly and at a steady, confident pace.
2. Keep the video between 2:00 and 2:45 minutes.
3. Keep Loom video settings set to "Anyone with the link can view".
