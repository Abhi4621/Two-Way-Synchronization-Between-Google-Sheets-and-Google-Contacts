import os
import sys

# Ensure parent directory is in sys.path
root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from local_app import app

# Vercel WSGI entry point
# This exposes the Flask application instance
app = app
